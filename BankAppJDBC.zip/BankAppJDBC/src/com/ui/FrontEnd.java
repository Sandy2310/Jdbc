package com.ui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.bean.Bean;
import com.service.AccountService;

public class FrontEnd 
{
	
	AccountService service= new AccountService();
     Scanner sc= new Scanner(System.in);
	public void display() {
		
		
		
		for(;;)
	{
			Bean bean= new Bean();
			
	  System.out.println("-----Welcome to XYZ BANK-----");
      System.out.println("Press 1 to Create an Account");
      System.out.println("Press 2 to Show Balance");
      System.out.println("Press 3 to Deposit Amount ");
      System.out.println("Press 4 to Withdraw Amount");
      System.out.println("Press 5 to Cash Transfer");
      System.out.println("Press 6 to Show Transactions");
      System.out.println("Press 7 TO Exit ");
      
      
switch(sc.nextInt())
{
case 1:
System.out.println("Enter your Name");
bean.setName(sc.next());
bean.setAccountNumber((int)(1000+Math.random()*1000));
System.out.println("Enter your Amount");
bean.setBalance(sc.nextDouble());
System.out.println("Enter your phoneNumber");
bean.setPhoneNumber(sc.next());
service.createAccount(bean);
System.out.println("Account is created.");
System.out.println("Your Account Number is "+bean.getAccountNumber());
	break;

case 2:
	System.out.println("Enter your Account Number");
	int accountId=sc.nextInt();
	if(service.validateAccount(accountId))
	{
		System.out.println("Your Account balance is "+service.showBalance(accountId));
	}	
	else 
	{
	System.out.println("Invalid Account Id");
	}
	
		
	break;
		
case 3:
	System.out.println("Enter your Account Number");
			int accountId1=sc.nextInt();
	
		if(!service.validateAccount(accountId1))		
		{
		System.out.println("Invalid Account Id");
		}
	else 
	{
	System.out.println("Enter Amount to be deposited");
	double depositAmount=sc.nextDouble();
	System.out.println(service.depositAmount(accountId1,depositAmount));
	}
	break;
	
case 4:
	
	System.out.println("Enter your Account Number");
	int accountId2=sc.nextInt();

	if(!service.validateAccount(accountId2))
	{
		System.out.println("Invalid Account Id");
	}
	else {
	System.out.println("Enter Amount to be withdrawn");
	double withdrawAmount=sc.nextDouble();
	System.out.println(service.withdrawAmount(accountId2,withdrawAmount));
	}
	break;
	
case 5:
	System.out.println("Enter source account number");
	int source=sc.nextInt();

	if(!service.validateAccount(source))
	{
		System.out.println("Invalid Account Id");
	}
	else 
	{
	System.out.println("Enter destination account number");
	 int destination=sc.nextInt();
	if(!service.validateAccount(destination))
	{
		System.out.println("Invalid Account Id");
	}
	else
	{
	System.out.println("Enter the amount to be transferred");
	double money=sc.nextDouble();
	service.cashTransfer(source,destination,money);
	System.out.println("Transfer successful");
	}
	}
	break;
case 6:
	System.out.println("Enter Account Number");
	int accountNum=sc.nextInt();
	ResultSet set=service.getTransaction(accountNum);
	try
	{
		while(set.next())
		{
	    System.out.println("Account Number=" + set.getInt("accountNumber") +", credit=" + set.getDouble("credit") + ", debit="
                + set.getDouble("debit") + ",Balance=" + set.getDouble("Balance"));
		}
	}
	catch (SQLException e) {
            e.printStackTrace();
        }	
	break;
	
case 7: System.exit(0);
	break;
	
default:
		System.out.println("invalid enter again");
	break;
}
	}

}

}